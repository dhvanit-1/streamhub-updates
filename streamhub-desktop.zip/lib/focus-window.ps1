# Brings a process's main window to the front with keyboard focus (Windows only).
# Run by lib/mpv.js for the StreamHub player: it is started by the background server, and Windows does not let
# such a program take the foreground by itself (it only flashes its taskbar button). Sharing input with the
# current foreground window for a moment is the standard way an app brings its own second window forward.
#   powershell -NoProfile -ExecutionPolicy Bypass -File focus-window.ps1 -ProcessId <pid>
param([Parameter(Mandatory = $true)][int]$ProcessId, [int]$WaitMs = 8000)

Add-Type -Namespace StreamHub -Name Win -MemberDefinition @'
[DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
[DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, IntPtr processId);
[DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
[DllImport("user32.dll")] public static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
[DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr hWnd);
[DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
[DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hWnd);
public static bool Focus(IntPtr h) {
  IntPtr fg = GetForegroundWindow();
  if (fg == h) return true;
  uint fgThread = GetWindowThreadProcessId(fg, IntPtr.Zero);
  uint me = GetCurrentThreadId();
  bool attached = fgThread != 0 && fgThread != me && AttachThreadInput(me, fgThread, true);
  try {
    if (IsIconic(h)) ShowWindow(h, 9); // SW_RESTORE
    BringWindowToTop(h);
    return SetForegroundWindow(h);
  } finally {
    if (attached) AttachThreadInput(me, fgThread, false);
  }
}
'@

$deadline = (Get-Date).AddMilliseconds($WaitMs)
do {
  $p = Get-Process -Id $ProcessId -ErrorAction SilentlyContinue
  if (-not $p) { exit 2 }
  $h = $p.MainWindowHandle
  if ($h -ne [IntPtr]::Zero) {
    if ([StreamHub.Win]::Focus($h)) { exit 0 }
  }
  Start-Sleep -Milliseconds 200
  $p.Refresh()
} while ((Get-Date) -lt $deadline)
exit 1
