﻿This folder holds mpv (https://mpv.io), StreamHub's video player, run as a separate program.
Build: https://github.com/shinchiro/mpv-winbuild-cmake (linked from https://mpv.io/installation/).
Source: https://github.com/mpv-player/mpv. Licence: GPL v2 or later (this build includes GPL components).

mpv v0.41.0-1227-ge471496c5 Copyright © 2000-2026 mpv/MPlayer/mplayer2 projects
 built on Oct 21 2026 00:43:16
