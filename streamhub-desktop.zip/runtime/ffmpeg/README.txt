﻿This folder holds FFmpeg (https://ffmpeg.org), run by StreamHub as a separate program.
Source: https://ffmpeg.org/download.html. Licence: LICENSE.txt (LGPL v2.1 or later, unless the configure line below has --enable-gpl).

ffmpeg version 98581d5 Copyright (c) 2000-2026 the FFmpeg developers
built with gcc 16.2.0 (Rev6, Built by MSYS2 project)
configuration: --prefix=/c/ffmpeg-min --disable-everything --disable-autodetect --disable-doc --disable-debug --disable-ffplay --enable-small --enable-static --disable-shared --extra-ldflags=-static --enable-ffmpeg --enable-ffprobe --enable-swresample --enable-network --enable-schannel --enable-zlib --enable-protocol='file,pipe,http,https,tcp,tls,crypto' --enable-demuxer='matroska,mov,mpegts,hls,srt,ass,webvtt' --enable-decoder='ac3,eac3,dca,truehd,mlp,flac,opus,vorbis,mp3,aac,pcm_s16le,pcm_s24le,pcm_s32le,srt,subrip,ass,ssa,webvtt,mov_text' --enable-encoder='aac,webvtt' --enable-muxer='mp4,webvtt,null' --enable-parser='h264,hevc,av1,aac,ac3,dca,mlp,flac,opus,vorbis' --enable-bsf='h264_mp4toannexb,hevc_mp4toannexb,aac_adtstoasc,extract_extradata' --enable-filter='aresample,aformat,anull,null,pan'
